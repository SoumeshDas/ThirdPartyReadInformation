﻿using System;

namespace ROBOBAI_RECORD_INGESTION
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
