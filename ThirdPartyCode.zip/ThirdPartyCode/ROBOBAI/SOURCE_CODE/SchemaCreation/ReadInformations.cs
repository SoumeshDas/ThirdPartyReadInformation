﻿using Microsoft.Extensions.Logging;
using OfficeOpenXml;
using SCHEMACREATION.Entity;
using SCHEMACREATION.Entity.EntityDetails;
using SCHEMACREATION.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SCHEMACREATION
{
    public class ReadInformations
    {
        public string FilePath { get; set; }
        public int Gldatecounter { get; set; }

        private readonly ILogger _logger;

        public ReadInformations(ILogger<ReadInformations> logger)
        {
            _logger = logger;
        }
        
        public string CreateSchema()
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=TEST_DATA_BASE;Integrated Security=True");
            string query =
            @"CREATE TABLE TblCategory
                (
                SECONDITEMNUMBER NVARCHAR(340) NULL,
                THIRDITEMNUMBER NVARCHAR(340) NULL,
                ABNFLAG NVARCHAR(340) NULL,
                ABN BIGINT NULL,
                AUDINVOICELINEAMOUNTEXTAX INT NULL,
                ADDRESSNUMBERSHIPTO INT NULL,
                ADDRESSABLEPRIMARYINDUSTRY NVARCHAR(340) NULL,
                ALTERNATIVEVENDOR NVARCHAR(340) NULL,
                AMOUNTTAXABLE FLOAT NULL,
                AMOUNTUNITCOST FLOAT NULL,
                BUDIV NVARCHAR(340) NULL,
                BUDIVLEVEL1 NVARCHAR(340) NULL,
                BUDIVLEVEL2 NVARCHAR(340) NULL,
                BUDIVLEVEL3 NVARCHAR(340) NULL,
                BUDIVLEVEL4 NVARCHAR(340) NULL,
                BETTERPAYMENTTERM INT NULL,
                BRANCHPLANT NVARCHAR(340) NULL,
                BUSINESSSTREAMNAME NVARCHAR(340) NULL,
                BUSINESSSTREAM NVARCHAR(340) NULL,
                CSEABN NVARCHAR(340) NULL,
                CCOMPLIANTSPEND FLOAT NULL,
                CCOMPLIANCEPERCENTAGE FLOAT NULL,
                CLODLEVEL3 FLOAT NULL,
                TOP20CATEGORIESTITLEPNG NVARCHAR(340) NULL,
                AUDANDNZDSPEND FLOAT NULL,
                MULTIPLEDIMENSIONS NVARCHAR(340) NULL,
                ABC NVARCHAR(340) NULL,
                DONUT INT NULL,
                CALCULATION1 NVARCHAR(340) NULL,
                FIVEPERCENTAGESPEND FLOAT NULL,
                OAR4BUTTONS NVARCHAR(340) NULL,
                SPENDINMILLIONS FLOAT NULL,
                CCOMPTARGET NVARCHAR(340) NULL,
                CALENDARYEAR INT NULL,
                CATEGORISATIONQAFLAG NVARCHAR(340) NULL,
                CATEGORYRISK NVARCHAR(340) NULL,
                CLASSDESCRIPTION NVARCHAR(340) NULL,
                CLEANINVOICELINEDESCRIPTION NVARCHAR(340) NULL,
                COMMODITYCLASS NVARCHAR(340) NULL,
                COMMODITYDESCRIPTION NVARCHAR(340) NULL,
                COMMODITYSUBCLASS NVARCHAR(340) NULL,
                COMPANYNAME NVARCHAR(340) NULL,
                COMPANY INT NULL,
                COMPLIANCETARGET FLOAT NULL,
                CONTRACTPROJECTNAME NVARCHAR(340) NULL,
                CONTRACTPROJECTNUMBER INT NULL,
                COSTHEAD NVARCHAR(340) NULL,
                COUNTRY NVARCHAR(340) NULL,
                COUNTRYRISK NVARCHAR(340) NULL,
                CURRENCY NVARCHAR(340) NULL,
                CURRENCYCONVERSION FLOAT NULL,
                CURRENCYCONVERSIONNZ FLOAT NULL,
                DESCRIPTIONFORCATEGORISATION NVARCHAR(340) NULL,
                DELFLAG NVARCHAR(340) NULL,
                DEPARTMENTNAME NVARCHAR(340) NULL,
                DEPARTMENTSUBDIVISION INT NULL,
                DESCRIPTIONJDE NVARCHAR(340) NULL,
                DESCRIPTION NVARCHAR(340) NULL,
                DIRECTSINDIRECTS NVARCHAR(340) NULL,
                DIVISIONADDITIONNAME NVARCHAR(340) NULL,
                DIVISIONADDITION NVARCHAR(340) NULL,
                DIVISIONFORREPORTING NVARCHAR(340) NULL,
                DIVISIONNAME NVARCHAR(340) NULL,
                DIVISION NVARCHAR(340) NULL,
                DOCUMENTTYPE NVARCHAR(340) NULL,
                DOWNERENTITY NVARCHAR(340) NULL,
                DOWNERLEVEL1CATEGORY NVARCHAR(340) NULL,
                DOWNERLEVEL2CATEGORY NVARCHAR(340) NULL,
                DOWNERLEVEL3CATEGORY NVARCHAR(340) NULL,
                DOWNERCATEGORYID INT NULL,
                DUETYPE INT NULL,
                FILENAME NVARCHAR(340) NULL,
                FINANCIALYEAR INT NULL,
                GLCODE NVARCHAR(340) NULL,
                GLDATE DATETIME NULL,
                GLDESC NVARCHAR(340) NULL,
                GLDATEDUPLICATE DATETIME NULL,
                GST FLOAT NULL,
                GROSSAMOUNT FLOAT NULL,
                GROUPBUSINESSMANAGED NVARCHAR(340) NULL,
                INDIGENOUSAPPLICABLE NVARCHAR(340) NULL,
                INDIGENOUSSUPPLIERS NVARCHAR(340) NULL,
                INTERNALDOCUMENTNUMBER NVARCHAR(340) NULL,
                INVOICEDATE DATETIME NULL,
                INVOICEENTEREDBY NVARCHAR(340) NULL,
                INVOICEDFINAL INT NULL,
                ITEMDESCRIPTION NVARCHAR(340) NULL,
                ITEMNUMBERSHORT NVARCHAR(340) NULL,
                JDEXCOMMODITYSUBCLASS NVARCHAR(340) NULL,
                JDEXCOMMODITY NVARCHAR(340) NULL,
                L3L4CATEGORY NVARCHAR(340) NULL,
                LEGALENTITYNAME NVARCHAR(340) NULL,
                LEGALENTITY NVARCHAR(340) NULL,
                LINEID NVARCHAR(340) NULL,
                LINEOFBUSINESSDESCRIPTION NVARCHAR(340) NULL,
                LINEOFBUSINESS NVARCHAR(340) NULL,
                LOCATIONNAME NVARCHAR(340) NULL,
                LOCATION NVARCHAR(340) NULL,
                MEASURECOMPLIANCECATEGORY1 NVARCHAR(340) NULL,
                MEASURECOMPLIANCECATEGORY NVARCHAR(340) NULL,
                FY DATETIME NULL,
                CY DATETIME NULL,
                MONTH DATETIME NULL,
                MONTHFORMATTED DATETIME NULL,
                NZDINVOICELINEAMOUNTEXTAX FLOAT NULL,
                NETAMOUNT FLOAT NULL,
                NUMBEROFRECORDS INT NULL,
                ONETIME NVARCHAR(340) NULL,
                PO NVARCHAR(340) NULL,
                PANELSTATUS NVARCHAR(340) NULL,
                PARENTID INT NULL,
                PARTNUMBER NVARCHAR(340) NULL,
                PAYSTATUSCODE NVARCHAR(340) NULL,
                PAYMENTTERMS INT NULL,
                PAYMENTTERMDAYS INT NULL,
                PERCENTAGESAVING FLOAT NULL,
                POSTCODE INT NULL,
                POTENTIAL NVARCHAR(340) NULL,
                PREFERREDNOTPREFERREDCOPY NVARCHAR(340) NULL,
                PREFERREDNOTPREFERRED NVARCHAR(340) NULL,
                PRIMARYINDUSTRYLEVEL1 NVARCHAR(340) NULL,
                PRIMARYINDUSTRYLEVEL2 NVARCHAR(340) NULL,
                PRIMARYINDUSTRY NVARCHAR(340) NULL,
                PROCUREMENTOUTOFSCOPE NVARCHAR(340) NULL,
                PURCHASEORDERDATE NVARCHAR(340) NULL,
                PURCHASEORDERENTEREDBY NVARCHAR(340) NULL,
                QUANTITYDELIVERED FLOAT NULL,
                QUANTITYORDERED NVARCHAR(340) NULL,
                QUANTITY NVARCHAR(340) NULL,
                REGIONALOPERATIONALGROUPNAME NVARCHAR(340) NULL,
                REGIONALOPERATIONALGROUP NVARCHAR(340) NULL,
                REGIONALOPERATIONALSUBGROUPNAME NVARCHAR(340) NULL,
                REGIONALOPERATIONALSUBGROUP NVARCHAR(340) NULL,
                ROBOVENDORID INT NULL,
                ROBOBAIID INT NULL,
                SNORMQA NVARCHAR(340) NULL,
                SPENDBUCKET NVARCHAR(340) NULL,
                SAVINGS INT NULL,
                SCOPE NVARCHAR(340) NULL,
                SINGLEMULTIPLE NVARCHAR(340) NULL,
                SITEFORREPORTING NVARCHAR(340) NULL,
                STATEPOSTCODEFLAG NVARCHAR(340) NULL,
                STATE NVARCHAR(340) NULL,
                SUPPLIERCONTRACTED NVARCHAR(340) NULL,
                SUPPLIERINVOICEREFERENCE INT NULL,
                SUPPLIERNUMBER NVARCHAR(340) NULL,
                SUPPLIERPARTNUMBER NVARCHAR(340) NULL,
                SUPPLIERCHILDNAME NVARCHAR(340) NULL,
                SUPPLIERCOMPLIANCE NVARCHAR(340) NULL,
                SYSTEM NVARCHAR(340) NULL,
                THRE NVARCHAR(340) NULL,
                TIMESTAMP DATETIME NULL,
                UNIQUEID NVARCHAR(340) NULL,
                UNIQUEDET NVARCHAR(340) NULL,
                UNITPRICE FLOAT NULL,
                UNITOFMEASURE NVARCHAR(340) NULL,
                USERID NVARCHAR(340) NULL,
                VRINSCOPE NVARCHAR(340) NULL,
                VENDORNAME NVARCHAR(340) NULL,
                VENDORPOSTCODE NVARCHAR(340) NULL,
                VENDORSTATE NVARCHAR(340) NULL,
                CLODOARSPENDCAT FLOAT NULL,
                CLODOARSPEND FLOAT NULL,
                COUNTRY2 NVARCHAR(340) NULL,
                GROUPID INT NULL);";

            SqlCommand cmd = new SqlCommand(query, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                Console.WriteLine("Table Created Successfully");
            }
            catch (SqlException e)
            {
                Console.WriteLine("Error Generated. Details: " + e.ToString());
            }
            finally
            {
                con.Close();
                Console.ReadKey();
            }
            return "Details";
        }

        public List<Category> ReadDetailsRecords()
        {
            FileInfo file = new FileInfo(FilePath);
            int rowForException;
            var column1 = string.Empty;
            var rawText = string.Empty;
            var categoryInformations = new List<Category>();

           
            
            var currentDirectory = System.IO.Directory.GetCurrentDirectory();

            using (ExcelPackage package = new ExcelPackage(file))
            {
                StringBuilder sb = new StringBuilder();
                ExcelWorksheet worksheet = package.Workbook.Worksheets[0];
                int rowCount = worksheet.Dimension.Rows;
                int ColCount = worksheet.Dimension.Columns;
                var systeInfoColumnCardinal = worksheet.Dimension.Columns - 1;
                var systemInfoTimeStampColumn = worksheet.Dimension.Columns;

                Console.WriteLine("Excel Read Process Started");
                
                WriteLogFile.WriteLog("infolog.txt", "Excel Read Process started");
                for (int row = 2; row <= rowCount; row++)
                {
                    rowForException = row;
                    Category categoryformation = new Category();

                    PropertyInfo[] propertyInfos = categoryformation.GetType().GetProperties();

                    for (int col = 1; col <= ColCount; col++)
                    {
                        try
                        {
                            rawText = string.IsNullOrEmpty(Convert.ToString
                            (worksheet.Cells[row, col].Value)) ?
                            string.Empty : Convert.ToString(worksheet.Cells[row, col].Value).Trim();

                            var dtcol = col - 1;
                            column1 = Convert.ToString(dtcol);
                            if (!string.IsNullOrEmpty(rawText))
                            {

                                Type t = Nullable.GetUnderlyingType(propertyInfos[dtcol].PropertyType) ?? propertyInfos[dtcol].PropertyType;
                                object propvalue = new object();
                                DateTime dt;

                                if (t == typeof(DateTime))
                                {
                                    if (DateTime.TryParseExact(rawText, "dd/MM/yyyy", null, DateTimeStyles.None, out dt))
                                    {
                                        propvalue = dt;
                                    }
                                    else
                                    {
                                        propvalue = DateTime.Parse(rawText);
                                    }
                                }
                                else if (t == typeof(Guid))
                                {
                                    propvalue = Guid.Parse(rawText);
                                }
                                else
                                {
                                    propvalue = Convert.ChangeType(rawText, t);
                                }

                                object safeValue = (rawText == null) ? null : propvalue;

                                propertyInfos[dtcol].SetValue(categoryformation,
                                safeValue, null);
                            }
                            else
                            {
                                propertyInfos[dtcol].SetValue(categoryformation,
                                null, null);
                            }
                        }
                        catch (Exception ex)
                        {
                            var col23 = column1;
                            var cellvalue = rawText;
                            var status = string.Format("Exception{0} for column {1} and row {1} and cell value {3} at {4}", ex.ToString(), col, rowForException, cellvalue,DateTime.Now.ToString());
                            _logger.LogError(string.Format("Exception{0} for column {1} and row {1} and cell value {3}", ex.ToString(), col, rowForException, cellvalue));
                            Console.WriteLine(status);
                            WriteLogFile.WriteLog("errorlog.txt", status);
                        }
                    }
                    categoryInformations.Add(categoryformation);
                }
                //package.Save();
                Console.WriteLine(string.Format("Excel Read Process ended and total count of rows {0}", categoryInformations.Count));
                WriteLogFile.WriteLog("infolog.txt",string.Format("Excel Read Process ended and total count of rows {0} at {1}", categoryInformations.Count,DateTime.Now.ToString()));
            }
            return categoryInformations;
        }

        

        public void ReadFile()
        {
            FilePath = "X:\\ROBOBAI\\DATA\\CATEGORY\\2017\\Sample2.xlsx";
            _logger.LogInformation("Read files started");
            var table = ReadDetailsRecords();
            foreach (var records in table.ChunkBy(500))
            {
                _logger.LogInformation("Insert Records To DataBase");
                WriteLogFile.WriteLog("infolog.txt", string.Format("Insert Records To DataBase for rows {0} at {1}", records.Count, DateTime.Now.ToString()));
                Console.WriteLine(string.Format("Insert Records To DataBase for rows {0} at {1}", records.Count,DateTime.Now.ToString()));
                InsertRecords(table);
            }
            Console.WriteLine("Insert Records To DataBase ends");

        }

        public int InsertRecords(List<Category> insertrecords)
        {
            try
            {
                using (var connection = new SqlConnection(@"Data Source=.;Initial Catalog=TEST_DATA_BASE;Integrated Security=True"))
                {
                    connection.Open();
                    SqlTransaction transaction = connection.BeginTransaction();

                    using (var bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                    {
                        //bulkCopy.BatchSize = _batchSize;
                        bulkCopy.DestinationTableName = "TblCategory";
                        try
                        {
                            DataTable supplierInfos = insertrecords.AsDataTable();
                            bulkCopy.WriteToServer(supplierInfos);
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            connection.Close();
                            _logger.LogError(string.Format("Exception {0} for details changes", ex.ToString()));
                            WriteLogFile.WriteLog("errorlog.txt", string.Format("Database operations Exception {0} for details changes at {1}", ex.ToString(),DateTime.Now.ToString()));
                        }
                    }

                    transaction.Commit();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(string.Format("Exception {0} for details changes", ex.ToString(), ex.ToString()));
            }


            return 1;
        }

      
    }


}
