﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SCHEMACREATION.Entity
{
    public class TableAttributeInformation
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }
}
